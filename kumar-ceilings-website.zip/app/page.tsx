"use client"

import { useEffect, useRef, useState } from "react"
import { motion, useScroll, useTransform, useInView } from "framer-motion"
import { ArrowRight, CheckCircle, Phone, Mail, MapPin, Sparkles } from "lucide-react"
import Link from "next/link"
import AIVisualization from "@/components/ai-visualization"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

export default function Home() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const containerRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll()
  const opacity = useTransform(scrollYProgress, [0, 0.2], [1, 0])
  const scale = useTransform(scrollYProgress, [0, 0.2], [1, 0.8])

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY })
    }
    window.addEventListener("mousemove", handleMouseMove)
    return () => window.removeEventListener("mousemove", handleMouseMove)
  }, [])

  const services = [
    {
      title: "Gypsum & POP Ceiling",
      description: "Expert installation of premium gypsum and POP false ceilings for elegant interiors",
      image:
        "https://placehold.co/600x400?text=Luxury+gypsum+false+ceiling+installation+with+modern+recessed+lighting+and+smooth+white+finish",
      href: "/services/gypsum-pop",
    },
    {
      title: "Grid & PVC Ceilings",
      description: "Durable and aesthetic grid and PVC ceiling solutions for commercial and residential spaces",
      image:
        "https://placehold.co/600x400?text=Professional+grid+ceiling+installation+in+modern+office+with+clean+lines+and+acoustic+panels",
      href: "/services/grid-pvc",
    },
    {
      title: "LED & Cove Lighting",
      description: "Stunning LED installations and cove lighting to enhance your ceiling aesthetics",
      image:
        "https://placehold.co/600x400?text=Elegant+cove+lighting+design+with+warm+LED+strips+and+ambient+ceiling+glow",
      href: "/services/led-lighting",
    },
    {
      title: "Renovation & Repair",
      description: "Complete renovation, repair, and removal services for existing ceiling structures",
      image:
        "https://placehold.co/600x400?text=Professional+ceiling+renovation+before+after+transformation+with+modern+design",
      href: "/services/renovation-repair",
    },
    {
      title: "Ceiling Trims & Medallions",
      description: "Decorative ceiling trims and medallions for a luxurious finishing touch",
      image: "https://placehold.co/600x400?text=Ornate+ceiling+medallion+with+intricate+details+and+crown+molding+trim",
      href: "/services/trims-medallions",
    },
  ]

  const whyChooseUs = [
    {
      icon: <CheckCircle className="w-8 h-8" />,
      title: "6 Months Warranty",
      description: "Exclusive workmanship warranty that no one else provides",
    },
    {
      icon: <CheckCircle className="w-8 h-8" />,
      title: "No Delays",
      description: "On-time project completion guaranteed",
    },
    {
      icon: <CheckCircle className="w-8 h-8" />,
      title: "Affordable Pricing",
      description: "Premium quality ceilings within every budget",
    },
    {
      icon: <CheckCircle className="w-8 h-8" />,
      title: "Free Consultation",
      description: "Complimentary design consultation and custom solutions",
    },
    {
      icon: <CheckCircle className="w-8 h-8" />,
      title: "Skilled Team",
      description: "Professional craftsmen with 25+ years of expertise",
    },
    {
      icon: <CheckCircle className="w-8 h-8" />,
      title: "Quality Materials",
      description: "Only premium grade materials for lasting durability",
    },
  ]

  return (
    <div ref={containerRef} className="relative bg-black text-white overflow-hidden">
      {/* Animated cursor follower */}
      <motion.div
        className="fixed w-6 h-6 bg-amber-500/30 rounded-full pointer-events-none z-50 mix-blend-screen"
        animate={{
          x: mousePosition.x - 12,
          y: mousePosition.y - 12,
        }}
        transition={{ type: "spring", stiffness: 500, damping: 28 }}
      />

      {/* Navigation */}
      <motion.nav
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className="fixed top-0 left-0 right-0 z-40 bg-black/80 backdrop-blur-lg border-b border-white/10"
      >
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <motion.div
            className="text-2xl font-bold bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent"
            whileHover={{ scale: 1.05 }}
          >
            Kumar Ceilings
          </motion.div>
          <div className="flex gap-8 items-center">
            <a href="#services" className="hover:text-amber-400 transition-colors">
              Services
            </a>
            <a href="#visualize" className="hover:text-amber-400 transition-colors">
              Visualize
            </a>
            <a href="#why-us" className="hover:text-amber-400 transition-colors">
              Why Us
            </a>
            <a href="#contact" className="hover:text-amber-400 transition-colors">
              Contact
            </a>
          </div>
        </div>
      </motion.nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
        {/* Animated background gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-amber-900/20 via-black to-orange-900/20" />

        {/* 3D floating elements */}
        <motion.div
          className="absolute inset-0"
          style={{
            backgroundImage: "radial-gradient(circle at 50% 50%, rgba(251, 191, 36, 0.1) 0%, transparent 50%)",
          }}
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3],
          }}
          transition={{
            duration: 8,
            repeat: Number.POSITIVE_INFINITY,
            ease: "easeInOut",
          }}
        />

        <motion.div className="relative z-10 text-center px-6 max-w-5xl" style={{ opacity, scale }}>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="inline-block mb-6"
          >
            <span className="px-4 py-2 bg-amber-500/10 border border-amber-500/30 rounded-full text-amber-400 text-sm font-medium">
              25+ Years of Excellence
            </span>
          </motion.div>

          <motion.h1
            className="text-7xl md:text-8xl font-bold mb-6 leading-tight"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.4 }}
          >
            <span className="bg-gradient-to-r from-white via-amber-200 to-orange-400 bg-clip-text text-transparent">
              Elevate Your Space
            </span>
          </motion.h1>

          <motion.p
            className="text-xl md:text-2xl text-gray-300 mb-12 leading-relaxed"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.6 }}
          >
            Premium ceiling installations for homes, apartments, and commercial spaces.
            <br />
            Transforming ordinary ceilings into extraordinary designs.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.8 }}
            className="flex gap-4 justify-center"
          >
            <Button
              size="lg"
              className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-semibold px-8 py-6 text-lg rounded-full group"
            >
              Get Free Consultation
              <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-amber-500/50 text-amber-400 hover:bg-amber-500/10 px-8 py-6 text-lg rounded-full bg-transparent"
            >
              View Our Work
            </Button>
          </motion.div>
        </motion.div>

        {/* Scroll indicator */}
        <motion.div
          className="absolute bottom-10 left-1/2 -translate-x-1/2"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
        >
          <div className="w-6 h-10 border-2 border-amber-500/50 rounded-full p-1">
            <motion.div
              className="w-1.5 h-1.5 bg-amber-500 rounded-full mx-auto"
              animate={{ y: [0, 20, 0] }}
              transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
            />
          </div>
        </motion.div>
      </section>

      {/* Marquee Section */}
      <div className="relative py-8 bg-gradient-to-r from-amber-600 to-orange-600 overflow-hidden">
        <motion.div
          className="flex whitespace-nowrap"
          animate={{ x: [0, -1000] }}
          transition={{ duration: 20, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
        >
          {[...Array(10)].map((_, i) => (
            <span key={i} className="text-2xl font-bold mx-8">
              • Premium Ceiling Solutions
            </span>
          ))}
        </motion.div>
      </div>

      {/* Services Section */}
      <section id="services" className="relative py-32 px-6">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-20"
          >
            <h2 className="text-5xl md:text-6xl font-bold mb-6">
              <span className="bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">
                Our Services
              </span>
            </h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Comprehensive ceiling solutions tailored to your vision
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <ServiceCard key={index} service={service} index={index} />
            ))}
          </div>
        </div>
      </section>

      {/* AI Visualization Section */}
      <section id="visualize" className="relative py-32 px-6 bg-gradient-to-b from-black via-amber-950/10 to-black">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-amber-500/20 to-orange-500/20 border border-amber-500/30 rounded-full mb-6">
              <Sparkles className="w-5 h-5 text-amber-400" />
              <span className="text-amber-400 font-medium">AI-Powered Design</span>
            </div>
            <h2 className="text-5xl md:text-6xl font-bold mb-6">
              <span className="bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">
                Visualize Your Dream Ceiling
              </span>
            </h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Describe your ideal ceiling design and watch AI bring it to life instantly
            </p>
          </motion.div>

          <AIVisualization />
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section id="why-us" className="relative py-32 px-6">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-20"
          >
            <h2 className="text-5xl md:text-6xl font-bold mb-6">
              <span className="bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">
                Why Choose Us?
              </span>
            </h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">Unmatched quality, reliability, and craftsmanship</p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {whyChooseUs.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -10, scale: 1.02 }}
                className="group"
              >
                <Card className="bg-gradient-to-br from-amber-950/30 to-orange-950/30 border-amber-500/20 hover:border-amber-500/50 transition-all duration-300 p-8 h-full">
                  <div className="text-amber-500 mb-4 group-hover:scale-110 transition-transform">{item.icon}</div>
                  <h3 className="text-2xl font-bold mb-3 text-white">{item.title}</h3>
                  <p className="text-gray-400 leading-relaxed">{item.description}</p>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="relative py-32 px-6 bg-gradient-to-b from-black to-amber-950/20">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl md:text-6xl font-bold mb-6">
              <span className="bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">
                Get In Touch
              </span>
            </h2>
            <p className="text-xl text-gray-400">Ready to transform your space? Contact us today!</p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6">
            <motion.a
              href="tel:7845382294"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              whileHover={{ y: -10, scale: 1.05 }}
              className="group"
            >
              <Card className="bg-gradient-to-br from-amber-950/30 to-orange-950/30 border-amber-500/20 hover:border-amber-500/50 transition-all duration-300 p-8 text-center cursor-pointer">
                <div className="w-16 h-16 bg-amber-500/20 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-amber-500/30 transition-colors">
                  <Phone className="w-8 h-8 text-amber-500" />
                </div>
                <h3 className="text-xl font-bold mb-2 text-white">Call Us</h3>
                <p className="text-gray-400 text-sm">7845382294</p>
                <p className="text-gray-400 text-sm">+91 98942 54194</p>
              </Card>
            </motion.a>

            <motion.a
              href="mailto:ashsolutions.info@gmail.com"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              viewport={{ once: true }}
              whileHover={{ y: -10, scale: 1.05 }}
              className="group"
            >
              <Card className="bg-gradient-to-br from-amber-950/30 to-orange-950/30 border-amber-500/20 hover:border-amber-500/50 transition-all duration-300 p-8 text-center cursor-pointer">
                <div className="w-16 h-16 bg-amber-500/20 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-amber-500/30 transition-colors">
                  <Mail className="w-8 h-8 text-amber-500" />
                </div>
                <h3 className="text-xl font-bold mb-2 text-white">Email Us</h3>
                <p className="text-gray-400 text-sm break-all">ashsolutions.info@gmail.com</p>
              </Card>
            </motion.a>

            <motion.a
              href="https://www.google.com/maps/search/?api=1&query=No.6+Thandavarayan+Nagar+Orikkai+Kanchipuram+Tamil+Nadu+India"
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              viewport={{ once: true }}
              whileHover={{ y: -10, scale: 1.05 }}
              className="group"
            >
              <Card className="bg-gradient-to-br from-amber-950/30 to-orange-950/30 border-amber-500/20 hover:border-amber-500/50 transition-all duration-300 p-8 text-center cursor-pointer">
                <div className="w-16 h-16 bg-amber-500/20 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-amber-500/30 transition-colors">
                  <MapPin className="w-8 h-8 text-amber-500" />
                </div>
                <h3 className="text-xl font-bold mb-2 text-white">Visit Us</h3>
                <p className="text-gray-400 text-sm">No.6 Thandavarayan Nagar, Orikkai, Kanchipuram</p>
              </Card>
            </motion.a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative py-12 px-6 border-t border-white/10">
        <div className="max-w-7xl mx-auto text-center">
          <div className="text-3xl font-bold bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent mb-4">
            Kumar Ceilings
          </div>
          <p className="text-gray-400 mb-2">25+ Years of Excellence in Ceiling Installations</p>
          <p className="text-gray-500 text-sm">© {new Date().getFullYear()} Kumar Ceilings. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}

function ServiceCard({ service, index }: { service: any; index: number }) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true })

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 50 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      whileHover={{ y: -15, scale: 1.03 }}
      className="group"
    >
      <Link href={service.href}>
        <Card className="bg-gradient-to-br from-zinc-900 to-black border-amber-500/20 hover:border-amber-500/50 transition-all duration-500 overflow-hidden h-full cursor-pointer">
          <div className="relative overflow-hidden h-64">
            <motion.img
              src={service.image}
              alt={service.title}
              className="w-full h-full object-cover"
              whileHover={{ scale: 1.1 }}
              transition={{ duration: 0.6 }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />
          </div>
          <div className="p-6">
            <h3 className="text-2xl font-bold mb-3 text-white group-hover:text-amber-400 transition-colors">
              {service.title}
            </h3>
            <p className="text-gray-400 leading-relaxed mb-4">{service.description}</p>
            <div className="flex items-center text-amber-400 font-semibold group-hover:gap-2 transition-all">
              Learn More
              <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        </Card>
      </Link>
    </motion.div>
  )
}
