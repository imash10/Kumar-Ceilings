"use client"

import { motion } from "framer-motion"
import { ArrowLeft, CheckCircle, XCircle, Phone } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

export default function GypsumPopPage() {
  const designImages = [
    "https://placehold.co/800x600?text=Modern+gypsum+ceiling+with+recessed+LED+lighting+in+luxury+living+room",
    "https://placehold.co/800x600?text=Elegant+POP+false+ceiling+design+with+decorative+cove+lighting",
    "https://placehold.co/800x600?text=Contemporary+gypsum+ceiling+with+geometric+patterns+and+ambient+lights",
    "https://placehold.co/800x600?text=Classic+POP+ceiling+installation+with+chandelier+and+crown+molding",
    "https://placehold.co/800x600?text=Minimalist+white+gypsum+ceiling+with+hidden+LED+strips",
    "https://placehold.co/800x600?text=Ornate+POP+ceiling+design+with+multiple+layers+and+warm+lighting",
    "https://placehold.co/800x600?text=Modern+bedroom+gypsum+ceiling+with+indirect+cove+lighting",
    "https://placehold.co/800x600?text=Luxurious+dining+room+POP+ceiling+with+crystal+chandelier+centerpiece",
    "https://placehold.co/800x600?text=Office+space+gypsum+ceiling+with+clean+lines+and+spotlights",
    "https://placehold.co/800x600?text=Villa+entrance+hall+POP+ceiling+with+grand+design+and+gold+accents",
  ]

  const advantages = [
    "Seamless, smooth finish that enhances room aesthetics",
    "Excellent sound insulation properties",
    "Fire-resistant and moisture-resistant options available",
    "Easy to install and modify",
    "Can hide electrical wiring, pipes, and air conditioning ducts",
    "Lightweight and durable material",
    "Allows creative designs with curves and complex shapes",
    "Improves room insulation and energy efficiency",
  ]

  const disadvantages = [
    "Requires professional installation for best results",
    "May crack over time due to settling or vibrations",
    "Not ideal for areas with high moisture without proper waterproofing",
    "Initial cost can be higher than basic ceiling options",
  ]

  const scrollToContact = () => {
    window.location.href = "/#contact"
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <section className="relative min-h-[60vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-amber-900/30 via-black to-orange-900/30" />

        <motion.div
          className="absolute inset-0"
          animate={{
            backgroundPosition: ["0% 0%", "100% 100%"],
          }}
          transition={{
            duration: 20,
            repeat: Number.POSITIVE_INFINITY,
            repeatType: "reverse",
          }}
          style={{
            backgroundImage: "radial-gradient(circle at 50% 50%, rgba(251, 191, 36, 0.1) 0%, transparent 50%)",
            backgroundSize: "200% 200%",
          }}
        />

        <div className="relative z-10 max-w-5xl mx-auto px-6 py-20 text-center">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
            <Link href="/">
              <Button
                variant="outline"
                className="mb-8 border-amber-500/50 text-amber-400 hover:bg-amber-500/10 bg-transparent"
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Home
              </Button>
            </Link>

            <h1 className="text-6xl md:text-7xl font-bold mb-6">
              <span className="bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">
                Gypsum & POP Ceiling Installation
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 leading-relaxed max-w-3xl mx-auto">
              Transform your interiors with premium gypsum and POP false ceilings that combine elegance, functionality,
              and timeless design.
            </p>
          </motion.div>
        </div>
      </section>

      {/* What is Gypsum & POP Section */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-8 bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">
              What is Gypsum & POP Ceiling?
            </h2>
            <div className="space-y-6 text-lg text-gray-300 leading-relaxed">
              <p>
                <span className="text-amber-400 font-semibold">Gypsum ceilings</span> are made from gypsum boards (also
                known as drywall or plasterboard), which are panels made of calcium sulfate dihydrate. These boards are
                lightweight, fire-resistant, and easy to work with, making them ideal for creating smooth, modern
                ceiling designs.
              </p>
              <p>
                <span className="text-amber-400 font-semibold">POP (Plaster of Paris) ceilings</span> use a white powder
                made from gypsum that, when mixed with water, forms a paste that can be molded into intricate designs.
                POP is perfect for creating decorative elements, ornate patterns, and classical ceiling designs with
                curves and detailed craftsmanship.
              </p>
              <p>
                Both materials are popular choices for false ceilings in homes, apartments, and commercial spaces due to
                their versatility, aesthetic appeal, and practical benefits like concealing wiring and improving
                acoustics.
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Why Install Section */}
      <section className="py-20 px-6 bg-gradient-to-b from-black via-amber-950/10 to-black">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-8 bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">
              Why You Should Install Gypsum & POP Ceilings
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-gradient-to-br from-amber-950/30 to-orange-950/30 border-amber-500/20 p-8">
                <h3 className="text-2xl font-bold text-amber-400 mb-4">Aesthetic Enhancement</h3>
                <p className="text-gray-300 leading-relaxed">
                  Transform ordinary spaces into stunning interiors with elegant designs, smooth finishes, and the
                  ability to incorporate modern lighting solutions that create the perfect ambiance.
                </p>
              </Card>
              <Card className="bg-gradient-to-br from-amber-950/30 to-orange-950/30 border-amber-500/20 p-8">
                <h3 className="text-2xl font-bold text-amber-400 mb-4">Functional Benefits</h3>
                <p className="text-gray-300 leading-relaxed">
                  Conceal unsightly wiring, pipes, and ductwork while improving room acoustics, thermal insulation, and
                  overall energy efficiency of your space.
                </p>
              </Card>
              <Card className="bg-gradient-to-br from-amber-950/30 to-orange-950/30 border-amber-500/20 p-8">
                <h3 className="text-2xl font-bold text-amber-400 mb-4">Property Value</h3>
                <p className="text-gray-300 leading-relaxed">
                  Increase your property's market value with premium ceiling installations that appeal to buyers and
                  create a lasting impression of quality and sophistication.
                </p>
              </Card>
              <Card className="bg-gradient-to-br from-amber-950/30 to-orange-950/30 border-amber-500/20 p-8">
                <h3 className="text-2xl font-bold text-amber-400 mb-4">Customization</h3>
                <p className="text-gray-300 leading-relaxed">
                  Express your unique style with endless design possibilities, from minimalist modern to ornate
                  classical, all tailored to your specific vision and space requirements.
                </p>
              </Card>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Advantages Section */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-12 bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">
              Advantages
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              {advantages.map((advantage, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="flex items-start gap-4"
                >
                  <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0 mt-1" />
                  <p className="text-gray-300 text-lg leading-relaxed">{advantage}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Disadvantages Section */}
      <section className="py-20 px-6 bg-gradient-to-b from-black via-amber-950/10 to-black">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-12 bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">
              Considerations
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              {disadvantages.map((disadvantage, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="flex items-start gap-4"
                >
                  <XCircle className="w-6 h-6 text-orange-500 flex-shrink-0 mt-1" />
                  <p className="text-gray-300 text-lg leading-relaxed">{disadvantage}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Design Gallery */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">
              Our Gypsum & POP Ceiling Designs
            </h2>
            <p className="text-xl text-gray-400">Explore our portfolio of stunning ceiling installations</p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {designImages.map((image, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ scale: 1.05, y: -10 }}
                className="group relative overflow-hidden rounded-xl"
              >
                <div className="aspect-[4/3] overflow-hidden bg-gradient-to-br from-zinc-800 to-zinc-900">
                  <img
                    src={image || "/placeholder.svg"}
                    alt={`Gypsum and POP ceiling design ${index + 1}`}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-6 bg-gradient-to-b from-black to-amber-950/20">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">
              Ready to Transform Your Ceiling?
            </h2>
            <p className="text-xl text-gray-300 mb-10 leading-relaxed">
              Get a free consultation and quote for your gypsum or POP ceiling installation project
            </p>
            <Button
              onClick={scrollToContact}
              size="lg"
              className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-semibold px-12 py-6 text-lg rounded-full group"
            >
              <Phone className="mr-2 h-5 w-5" />
              Get a Quote
            </Button>
          </motion.div>
        </div>
      </section>
    </div>
  )
}
