"use client"

import { motion } from "framer-motion"
import { ArrowLeft, CheckCircle, XCircle, Phone } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

export default function GridPVCPage() {
  const designImages = [
    "https://placehold.co/800x600?text=Modern+office+grid+ceiling+with+acoustic+tiles+and+LED+panels",
    "https://placehold.co/800x600?text=Commercial+space+with+white+PVC+ceiling+panels+and+recessed+lights",
    "https://placehold.co/800x600?text=Hospital+corridor+with+clean+grid+ceiling+and+fluorescent+lighting",
    "https://placehold.co/800x600?text=Retail+store+PVC+ceiling+installation+with+spot+lighting",
    "https://placehold.co/800x600?text=Elegant+restaurant+grid+ceiling+with+decorative+panels",
    "https://placehold.co/800x600?text=Bathroom+waterproof+PVC+ceiling+with+moisture+resistant+finish",
    "https://placehold.co/800x600?text=Conference+room+acoustic+grid+ceiling+with+sound+absorption",
    "https://placehold.co/800x600?text=Kitchen+PVC+ceiling+installation+with+easy+clean+surface",
    "https://placehold.co/800x600?text=Classroom+grid+ceiling+with+integrated+HVAC+and+lighting",
    "https://placehold.co/800x600?text=Showroom+designer+PVC+ceiling+with+modern+aesthetic",
  ]

  const advantages = [
    "Extremely durable and long-lasting material",
    "100% waterproof - perfect for bathrooms and kitchens",
    "Low maintenance - easy to clean and maintain",
    "Cost-effective solution for large areas",
    "Quick and easy installation process",
    "Termite-proof and pest-resistant",
    "Excellent for commercial and industrial spaces",
    "Wide variety of colors, patterns, and finishes available",
    "Good acoustic properties for noise reduction",
    "Eco-friendly and recyclable options available",
  ]

  const disadvantages = [
    "May not offer the same premium aesthetic as gypsum",
    "Can expand or contract with extreme temperature changes",
    "Limited design flexibility compared to POP ceilings",
    "May discolor over time with prolonged UV exposure",
  ]

  const scrollToContact = () => {
    window.location.href = "/#contact"
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <section className="relative min-h-[60vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/30 via-black to-cyan-900/30" />

        <motion.div
          className="absolute inset-0"
          animate={{
            backgroundPosition: ["0% 0%", "100% 100%"],
          }}
          transition={{
            duration: 20,
            repeat: Number.POSITIVE_INFINITY,
            repeatType: "reverse",
          }}
          style={{
            backgroundImage: "radial-gradient(circle at 50% 50%, rgba(59, 130, 246, 0.1) 0%, transparent 50%)",
            backgroundSize: "200% 200%",
          }}
        />

        <div className="relative z-10 max-w-5xl mx-auto px-6 py-20 text-center">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
            <Link href="/">
              <Button
                variant="outline"
                className="mb-8 border-amber-500/50 text-amber-400 hover:bg-amber-500/10 bg-transparent"
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Home
              </Button>
            </Link>

            <h1 className="text-6xl md:text-7xl font-bold mb-6">
              <span className="bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">
                Grid & PVC Ceiling Solutions
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 leading-relaxed max-w-3xl mx-auto">
              Durable, practical, and cost-effective ceiling solutions perfect for commercial spaces, bathrooms,
              kitchens, and high-moisture areas.
            </p>
          </motion.div>
        </div>
      </section>

      {/* What is Grid & PVC Section */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-8 bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">
              What are Grid & PVC Ceilings?
            </h2>
            <div className="space-y-6 text-lg text-gray-300 leading-relaxed">
              <p>
                <span className="text-amber-400 font-semibold">Grid ceilings</span> (also known as suspended ceilings or
                drop ceilings) consist of a metal framework grid suspended from the structural ceiling. This grid holds
                modular ceiling tiles or panels, typically made of mineral fiber, fiberglass, or metal. Grid ceilings
                are extremely popular in commercial buildings, offices, and institutional spaces.
              </p>
              <p>
                <span className="text-amber-400 font-semibold">PVC ceilings</span> use polyvinyl chloride panels or
                tiles that are lightweight, waterproof, and highly durable. PVC ceiling panels come in various designs,
                colors, and finishes, making them versatile for both residential and commercial applications. They're
                particularly ideal for areas with high moisture levels like bathrooms, kitchens, and basements.
              </p>
              <p>
                Both systems offer excellent accessibility to the plenum space above, making them ideal when you need
                frequent access to wiring, plumbing, HVAC systems, or other utilities hidden above the ceiling.
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Why Install Section */}
      <section className="py-20 px-6 bg-gradient-to-b from-black via-amber-950/10 to-black">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-8 bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">
              Why Choose Grid & PVC Ceilings
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-gradient-to-br from-amber-950/30 to-orange-950/30 border-amber-500/20 p-8">
                <h3 className="text-2xl font-bold text-amber-400 mb-4">Durability & Longevity</h3>
                <p className="text-gray-300 leading-relaxed">
                  Built to last with materials that resist moisture, pests, and wear. Perfect for high-traffic
                  commercial areas and moisture-prone residential spaces that need reliable, long-term solutions.
                </p>
              </Card>
              <Card className="bg-gradient-to-br from-amber-950/30 to-orange-950/30 border-amber-500/20 p-8">
                <h3 className="text-2xl font-bold text-amber-400 mb-4">Easy Maintenance</h3>
                <p className="text-gray-300 leading-relaxed">
                  Simple to clean and maintain with minimal effort. Individual panels can be easily replaced if damaged,
                  and the smooth surfaces resist staining and are easy to wipe clean.
                </p>
              </Card>
              <Card className="bg-gradient-to-br from-amber-950/30 to-orange-950/30 border-amber-500/20 p-8">
                <h3 className="text-2xl font-bold text-amber-400 mb-4">Cost-Effective</h3>
                <p className="text-gray-300 leading-relaxed">
                  Affordable installation and material costs make grid and PVC ceilings an economical choice for large
                  areas and commercial projects without compromising on quality or functionality.
                </p>
              </Card>
              <Card className="bg-gradient-to-br from-amber-950/30 to-orange-950/30 border-amber-500/20 p-8">
                <h3 className="text-2xl font-bold text-amber-400 mb-4">Easy Access</h3>
                <p className="text-gray-300 leading-relaxed">
                  Quick and convenient access to utilities above the ceiling. Perfect for buildings that require
                  frequent maintenance of electrical, HVAC, or plumbing systems without major disruption.
                </p>
              </Card>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Advantages Section */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-12 bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">
              Advantages
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              {advantages.map((advantage, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="flex items-start gap-4"
                >
                  <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0 mt-1" />
                  <p className="text-gray-300 text-lg leading-relaxed">{advantage}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Disadvantages Section */}
      <section className="py-20 px-6 bg-gradient-to-b from-black via-amber-950/10 to-black">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-12 bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">
              Considerations
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              {disadvantages.map((disadvantage, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="flex items-start gap-4"
                >
                  <XCircle className="w-6 h-6 text-orange-500 flex-shrink-0 mt-1" />
                  <p className="text-gray-300 text-lg leading-relaxed">{disadvantage}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Design Gallery */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">
              Grid & PVC Ceiling Installations
            </h2>
            <p className="text-xl text-gray-400">Professional installations across various spaces</p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {designImages.map((image, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ scale: 1.05, y: -10 }}
                className="group relative overflow-hidden rounded-xl"
              >
                <div className="aspect-[4/3] overflow-hidden bg-gradient-to-br from-zinc-800 to-zinc-900">
                  <img
                    src={image || "/placeholder.svg"}
                    alt={`Grid and PVC ceiling design ${index + 1}`}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-6 bg-gradient-to-b from-black to-amber-950/20">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">
              Need a Durable Ceiling Solution?
            </h2>
            <p className="text-xl text-gray-300 mb-10 leading-relaxed">
              Contact us for a free consultation on grid or PVC ceiling installation
            </p>
            <Button
              onClick={scrollToContact}
              size="lg"
              className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-semibold px-12 py-6 text-lg rounded-full group"
            >
              <Phone className="mr-2 h-5 w-5" />
              Get a Quote
            </Button>
          </motion.div>
        </div>
      </section>
    </div>
  )
}
