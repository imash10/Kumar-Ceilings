"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Loader2, Wand2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card } from "@/components/ui/card"

export default function AIVisualization() {
  const [prompt, setPrompt] = useState("")
  const [generatedImage, setGeneratedImage] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [error, setError] = useState("")

  const generateImage = async () => {
    if (!prompt.trim()) {
      setError("Please describe your ceiling design")
      return
    }

    setIsGenerating(true)
    setError("")
    setGeneratedImage("")

    try {
      const response = await fetch("https://llm.blackbox.ai/chat/completions", {
        method: "POST",
        headers: {
          customerId: "[USER_CUSTOMER_ID]",
          "Content-Type": "application/json",
          Authorization: "Bearer xxx",
        },
        body: JSON.stringify({
          model: "replicate/black-forest-labs/flux-1.1-pro",
          messages: [
            {
              role: "system",
              content: "You are a helpful AI assistant.",
            },
            {
              role: "user",
              content: `Generate an image: Professional interior ceiling design photo showing ${prompt}. High-quality architectural photography, realistic lighting, premium materials, elegant finish`,
            },
          ],
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to generate image")
      }

      const data = await response.json()
      const imageUrl = data.choices[0]?.message?.content

      if (imageUrl) {
        setGeneratedImage(imageUrl)
      } else {
        throw new Error("No image URL in response")
      }
    } catch (err) {
      setError("Failed to generate image. Please try again.")
      console.error("Error generating image:", err)
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8 }}
      viewport={{ once: true }}
    >
      <Card className="bg-gradient-to-br from-zinc-900/80 to-black/80 border-amber-500/30 backdrop-blur-lg p-8 md:p-12">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Input Section */}
          <div className="space-y-6">
            <div>
              <label className="block text-lg font-semibold mb-3 text-amber-400">Describe Your Dream Ceiling</label>
              <Textarea
                placeholder="E.g., Modern living room with gypsum ceiling, recessed LED lights, contemporary design with cove lighting around the perimeter, white finish..."
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                className="min-h-[200px] bg-black/50 border-amber-500/30 text-white placeholder:text-gray-500 focus:border-amber-500 resize-none"
              />
            </div>

            <Button
              onClick={generateImage}
              disabled={isGenerating}
              className="w-full bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-semibold py-6 text-lg rounded-xl group"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Generating Your Design...
                </>
              ) : (
                <>
                  <Wand2 className="mr-2 h-5 w-5 group-hover:rotate-12 transition-transform" />
                  Generate Design
                </>
              )}
            </Button>

            {error && (
              <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-red-400 text-sm">
                {error}
              </motion.p>
            )}

            <div className="pt-4 border-t border-amber-500/20">
              <p className="text-sm text-gray-400 leading-relaxed">
                <span className="text-amber-400 font-semibold">Pro Tips:</span> Be specific about room type, ceiling
                style (gypsum/POP/grid), lighting preferences, colors, and design elements for best results.
              </p>
            </div>
          </div>

          {/* Output Section */}
          <div className="relative">
            <div className="aspect-square rounded-xl overflow-hidden bg-gradient-to-br from-zinc-800 to-zinc-900 border border-amber-500/20">
              <AnimatePresence mode="wait">
                {isGenerating ? (
                  <motion.div
                    key="loading"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="w-full h-full flex flex-col items-center justify-center p-8"
                  >
                    <motion.div
                      animate={{
                        rotate: 360,
                        scale: [1, 1.2, 1],
                      }}
                      transition={{
                        rotate: { duration: 2, repeat: Number.POSITIVE_INFINITY, ease: "linear" },
                        scale: { duration: 1.5, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" },
                      }}
                      className="w-20 h-20 border-4 border-amber-500 border-t-transparent rounded-full mb-6"
                    />
                    <p className="text-amber-400 text-lg font-medium">Creating your ceiling design...</p>
                    <p className="text-gray-500 text-sm mt-2">This may take a moment</p>
                  </motion.div>
                ) : generatedImage ? (
                  <motion.div
                    key="image"
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                    transition={{ duration: 0.5 }}
                    className="w-full h-full"
                  >
                    <img
                      src={generatedImage || "/placeholder.svg"}
                      alt="Generated ceiling design"
                      className="w-full h-full object-cover"
                    />
                  </motion.div>
                ) : (
                  <motion.div
                    key="placeholder"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="w-full h-full flex items-center justify-center p-8 text-center"
                  >
                    <div>
                      <Wand2 className="w-16 h-16 text-amber-500/50 mx-auto mb-4" />
                      <p className="text-gray-400">Your AI-generated ceiling design will appear here</p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {generatedImage && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mt-4 text-center">
                <p className="text-sm text-gray-400">Love this design? Contact us to make it a reality!</p>
              </motion.div>
            )}
          </div>
        </div>
      </Card>
    </motion.div>
  )
}
